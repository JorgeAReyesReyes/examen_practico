import React, { useState } from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';  
import { Ionicons } from '@expo/vector-icons';

const Ahorro = ({ navigation }) => {
    const [count, setCount] = useState(0);
    
    const Increment = () => {
        setCount(count + 10);
    };
    
    const reset = () => {
        setCount(0);  
    };

    return (
        <View style={styles.container}> 
            <Text>Agregar al ahorro: {count}</Text>
            <Ionicons
                name="add-circle-outline" 
                size={40}
                color="green"
                onPress={Increment} 
            />
            <Text>Reset: {}</Text>
            <Ionicons
                name="refresh-circle-outline"
                size={40}
                color="red"
                onPress={reset}  
            />
            <View style={{ marginVertical: 20 }} />
            <Button title="Volver a Home" onPress={() => navigation.goBack()} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,  
        backgroundColor: '#87CEEB',  
        alignItems: 'center',  
        justifyContent: 'center',  
    },
});

export default Ahorro;