import React from 'react';
import { View, Text, Alert, Button, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const Configuracion = ({ navigation }) => {
    const handlePress = (opcion) => {
        Alert.alert("Configuración", `Has seleccionado: ${opcion}`);
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Configuración</Text>

            {/* Opción: Cambiar Idioma */}
            <TouchableOpacity style={styles.option} onPress={() => handlePress("Cambiar Idioma")}>
                <Ionicons name="globe-outline" size={30} color="black" />
                <Text style={styles.optionText}>Cambiar Idioma</Text>
            </TouchableOpacity>

            {/* Opción: Notificaciones */}
            <TouchableOpacity style={styles.option} onPress={() => handlePress("Notificaciones")}>
                <Ionicons name="notifications-outline" size={30} color="black" />
                <Text style={styles.optionText}>Notificaciones</Text>
            </TouchableOpacity>

            <View style={{ marginTop: 20 }}/>
                <Button title="Volver a Home" onPress={() => navigation.goBack()} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#87CEEB',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    option: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: 10,
        marginVertical: 10,
        borderRadius: 10,
        width: '80%',
        elevation: 3, // Sombra en Android
        shadowColor: '#000', // Sombra en iOS
        shadowOpacity: 0.2,
        shadowRadius: 5,
    },
    optionText: {
        fontSize: 18,
        marginLeft: 10,
    },
});

export default Configuracion;