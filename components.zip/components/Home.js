import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';

const Home = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Práctica Examen</Text>

            <View style={styles.buttonContainer}>
                <Button title="Ahorro" onPress={() => navigation.navigate('Ahorro')} />
            </View>
            <View style={styles.buttonContainer}>
                <Button title="Perfil" onPress={() => navigation.navigate('Perfil')} />
            </View>
            <View style={styles.buttonContainer}>
                <Button title="Configuración" onPress={() => navigation.navigate('Configuracion')} />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#87CEEB',
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    buttonContainer: {
        marginVertical: 10, 
    },
});

export default Home;