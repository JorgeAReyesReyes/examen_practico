import React from 'react';
import { View, Text, StyleSheet, Image, Button } from 'react-native';

const Perfil = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Image 
                source={require('../assets/images/foto.jpg')} 
                style={styles.image}
            />
            <Text style={styles.text}>
                <Text style={styles.title}>Perfil{"\n"}</Text>
                Nombre: Jorge Reyes{"\n"}
                Edad: 27{"\n"}
                Correo: Jorger@gmail.com{"\n"}
            </Text>

            <View style={{ marginVertical: 20 }} />
            <Button title="Volver a Home" onPress={() => navigation.goBack()} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#87CEEB',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
    },
    image: {
        width: 120,
        height: 120,
        marginBottom: 20,
    },
    text: {
        fontSize: 18,
        textAlign: 'center',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
    },
});

export default Perfil;